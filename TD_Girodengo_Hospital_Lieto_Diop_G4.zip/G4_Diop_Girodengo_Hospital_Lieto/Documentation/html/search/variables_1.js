var searchData=
[
  ['centerpos_710',['CenterPos',['../struct_pac_man.html#ac48cc21c3dff52b9fba7a30d68e7682f',1,'PacMan::CenterPos()'],['../struct_ghost_sprite.html#accb4ef836ac167184e397b12c056fc5e',1,'GhostSprite::CenterPos()']]],
  ['clickdata_711',['clickData',['../unionns_event_1_1_event_data__t.html#ac1478ee3007ce42a653e53c1200625bc',1,'nsEvent::EventData_t']]],
  ['color_712',['Color',['../struct_ghost_sprite.html#a44beb8d0ffced6c157785b586c1ecb24',1,'GhostSprite']]]
];
