var searchData=
[
  ['verticalalignment_786',['VerticalAlignment',['../classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80fa',1,'nsGui::Text']]]
];
