var searchData=
[
  ['bgtext_418',['BgText',['../class_bg_text.html',1,'']]]
];
