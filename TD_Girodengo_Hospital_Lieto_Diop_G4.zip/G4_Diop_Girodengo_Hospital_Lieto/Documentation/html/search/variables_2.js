var searchData=
[
  ['datamagic_713',['datamagic',['../sprite_8h.html#a43e5468a3d445613419004493d2ffac8',1,'sprite.h']]],
  ['directionactuelle_714',['DirectionActuelle',['../struct_pac_man.html#afafb2b6a4a78dade7a47563a1504f92a',1,'PacMan::DirectionActuelle()'],['../struct_ghost_sprite.html#a6e5f12d7d3e49f5abca7fc1df8179766',1,'GhostSprite::DirectionActuelle()']]],
  ['directionpred_715',['DirectionPred',['../struct_pac_man.html#a5d563ceac889bba46615381415ed7815',1,'PacMan::DirectionPred()'],['../struct_ghost_sprite.html#a031fb397fbdfa3ba0f3d6fa99e3a1aeb',1,'GhostSprite::DirectionPred()']]]
];
