var searchData=
[
  ['horizontalalignment_782',['HorizontalAlignment',['../classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dc',1,'nsGui::Text']]]
];
