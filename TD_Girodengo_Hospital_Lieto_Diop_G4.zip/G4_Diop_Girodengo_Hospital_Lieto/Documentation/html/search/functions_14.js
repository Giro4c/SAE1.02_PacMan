var searchData=
[
  ['xfinsidehitboxpacx_692',['xFInsideHitBoxPacX',['../collision_8cpp.html#a89a05d414bcffb03a7f23ca069bb8163',1,'xFInsideHitBoxPacX(const unsigned &amp;XCenterPac, const unsigned XPointFantome, const unsigned SizePac):&#160;collision.cpp'],['../collision_8h.html#a89a05d414bcffb03a7f23ca069bb8163',1,'xFInsideHitBoxPacX(const unsigned &amp;XCenterPac, const unsigned XPointFantome, const unsigned SizePac):&#160;collision.cpp']]]
];
