var searchData=
[
  ['id_720',['ID',['../struct_ghost_sprite.html#abf2891a46d24a5bf9bff806e74bbc9ee',1,'GhostSprite']]]
];
