var searchData=
[
  ['yfinsidehitboxpacy_693',['yFInsideHitBoxPacY',['../collision_8cpp.html#aa76d516ea65e9fc767f936a4bf1fdf30',1,'yFInsideHitBoxPacY(const unsigned &amp;YCenterPac, const unsigned YPointFantome, const unsigned SizePac, const unsigned &amp;XCenterPac, const unsigned XPointFantome):&#160;collision.cpp'],['../collision_8h.html#aa76d516ea65e9fc767f936a4bf1fdf30',1,'yFInsideHitBoxPacY(const unsigned &amp;YCenterPac, const unsigned YPointFantome, const unsigned SizePac, const unsigned &amp;XCenterPac, const unsigned XPointFantome):&#160;collision.cpp']]]
];
